<?php
	include 'AutoWPAPI.php';

	$wp = New AutoWP;
	$wp->SendAutoWP("666777888", "xxxxxx", "http://open.movilforum.com", "Visit us here")
?>